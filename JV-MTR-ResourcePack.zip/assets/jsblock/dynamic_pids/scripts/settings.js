
// It will default to local if the line is not in this list
let LINES = [
    {
        key: "快速|Rapid||Test",
        ch: "rapid_ch.png",
        en: "rapid_en.png"
    },
];

// It will default to 0 if the number of cars is not in this list
let carColorPalette = new Map([
    [0, 0x999999],
    [1, 0x992e2e],
    [2, 0xD4DB27],
    [3, 0xfa41f4],
    [4, 0xFA9141],
    [5, 0x6684ff],
    [6, 0x60BD2F],
    [7, 0x1FBADE],
    [8, 0x6C73BD],
    [9, 0x284269],
    [10, 0x9A59AA],
    [12, 0xEF545C],
    [15, 0x684528]
])